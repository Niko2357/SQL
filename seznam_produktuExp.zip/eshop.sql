create database eshop;
use eshop;

create table kategorie(
id int primary key identity(1,1),
nazev nvarchar(20), 
popis nvarchar(120)
);

create table produkt(
id int primary key identity(1,1),
nazev nvarchar(20),
cena int check(cena > 0),
kat_id int foreign key references kategorie(id)
);

select * from kategorie;

go
alter procedure novy_produkt @nazev_prod varchar(20), @cena  int,  @kategorie varchar(20)
as 
begin
	if exists(select nazev from  kategorie where nazev = @kategorie)
		insert into produkt(nazev, cena,  kat_id) values(@nazev_prod, @cena,  (select id from kategorie where nazev = @kategorie));
	else
		insert into  kategorie(nazev) values(@kategorie);
		insert into produkt(nazev, cena,  kat_id) values(@nazev_prod, @cena,  (select id from kategorie where nazev = @kategorie));
end
go

exec novy_produkt 'telefon', 8450, 'elektronika';
exec novy_produkt 'stul', 4520, 'nabytek';
exec novy_produkt 'zidle', 2000, 'nabytek';

go
create view seznam_produktu as 
select kategorie.nazev, produkt.nazev, produkt.cena
from kategorie inner join produkt on produkt.kat_id = kategorie.id;
go

select * from seznam_produktu order by nazev, cena;

go
create view kategorie_pocet_produktu as 
select kategorie.nazev, count(produkt.id) as pocet from produkt join kategorie on produkt.kat_id = kategorie.id group by kategorie.nazev;
go

select * from kategorie_pocet_produktu;

